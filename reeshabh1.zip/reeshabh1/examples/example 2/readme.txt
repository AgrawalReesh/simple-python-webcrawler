Query: Dog cat wolf
number of pages:  100